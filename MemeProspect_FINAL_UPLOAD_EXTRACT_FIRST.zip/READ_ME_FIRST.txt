FINAL MEME PROSPECT FILES

1. Extract this ZIP.
2. Open the folder named UPLOAD_THESE_6_FILES.
3. Upload ONLY the six .py files inside that folder to the ROOT of your GitHub repository.
4. They must be named exactly:
   config.py
   providers.py
   scoring.py
   scanner.py
   telegram.py
   main.py
5. GitHub should replace the existing files with those exact names.
6. Do NOT upload this ZIP itself to GitHub.
7. After commit, wait for Railway to redeploy.
8. Telegram /status should show:
   Interval: 60s
   🟡 Early Watch: 60/100
   🟢 Strong Prospect: 85/100
